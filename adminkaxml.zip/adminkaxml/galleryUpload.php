<?php

include('functions.php');
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}

$user_id = $_SESSION['user_id'];
$currentPage = $_POST['currentPage'];
if(isset($_POST['galleryUpload'])) {
    $target_dir = "galleryUploads/";
    $target_file_name = uniqid() . basename($_FILES["fileToUpload"]["name"]);
    $target_file = $target_dir . $target_file_name ;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

//    var_dump($_FILES["fileToUpload"]["tmp_name"]);die;
    if($_FILES["fileToUpload"]["tmp_name"] == ''){
        $_SESSION['uploadError'] = "Select an image.";
        header("location:gallery.php?page=$currentPage");
        die;
    }

// Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        $_SESSION['uploadError'] = "File is not an image.";
        header("location:gallery.php?page=$currentPage");
        $uploadOk = 0;
        die;
    }

// Check if file already exists
    if (file_exists($target_file)) {
        $_SESSION['uploadError'] = "Sorry, file already exists.";
        header("location:gallery.php?page=$currentPage");
        $uploadOk = 0;
        die;
    }
// Check file size
    if ($_FILES["fileToUpload"]["size"] > 1000000) {
        $_SESSION['uploadError'] = "Sorry, your file is too large.";
        header("location:gallery.php?page=$currentPage");
        $uploadOk = 0;
        die;
    }
// Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif") {
        $_SESSION['uploadError'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        header("location:gallery.php?page=$currentPage");
        $uploadOk = 0;
        die;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $_SESSION['uploadError'] = "Sorry, your file was not uploaded.";
        header("location:gallery.php?page=$currentPage");
        die;
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            addImage($user_id,$target_file_name);
            $pageCount = $_POST['pageCount'];
            header("location:gallery.php?page=$pageCount");
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}