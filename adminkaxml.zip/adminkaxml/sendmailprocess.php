<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$random = rand(100000,999999);

$mail = new PHPMailer();

$mail->isSMTP();

$mail->Host = 'smtp.mail.ru';
$mail->SMTPAuth = true;
$mail->Username = 'test.test314@mail.ru';
$mail->Password = 'testaccount123';
$mail->SMTPSecure = 'ssl';
$mail->Port = '465';

$mail->From = 'test.test314@mail.ru';
$mail->FromName = 'Batman';
$mail->addAddress($email);

//$mail->isHTML(true);

$mail->Subject = 'Do not answer to this message!';
$mail->Body    = 'Here is the verification code: ' . $random;
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';


if( $mail->send()){
    $_SESSION['random'] = $random;
}else{
    $_SESSION['code_err'] = 'Message can not be sent. ' . $mail->ErrorInfo;
}