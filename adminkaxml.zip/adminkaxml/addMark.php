<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}
$user_id = $_SESSION['user_id'];
$bool = false;
function addLatLng($userId,$latLng){
    $dom = new DOMDocument();
    $dom->formatOutput = true;
    $dom->load("users.xml", LIBXML_NOBLANKS);
    $root = $dom->documentElement;
    $i = 0;
    foreach($root->getElementsByTagName('user') as $user){
        if($root->getElementsByTagName('user')->item($i)->firstChild->nodeValue == $userId){
            $root->getElementsByTagName('user')->item($i)->childNodes->item(7)->nodeValue = $latLng[0];
            $root->getElementsByTagName('user')->item($i)->childNodes->item(8)->nodeValue = $latLng[1];
            $bool = $dom->save('users.xml');
            return $bool;
            break;
        }
        $i++;
    }
}
$lat = $_GET['lat'];
$lng = $_GET['lng'];
$latLng = [$lat,$lng];


if(addLatLng($user_id,$latLng)){
    echo 'Successfully added';
} else {
    echo 'Mark is not added!';
}



