<?php
session_start();
include ('layouts/header.php');
?>

    <div class='row'>
        <div class="col-md-8 col-md-offset-2">
            <h2 class="text-center">Login Form</h2>
            <form action="loginprocess.php" method="post">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" value="<?php
                    echo isset($_SESSION['email']) ? $_SESSION['email'] : '';
                    ?>" placeholder="Enter email" name="email">
                    <?php
                    if(isset($_SESSION['email_empty'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['email_empty'];
                            unset($_SESSION['email_empty']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
                    <?php
                    if(isset($_SESSION['wrong_password'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['wrong_password'];
                            unset($_SESSION['wrong_password']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <button type="submit" class="btn btn-default">Login</button>
                <a href="index.php" class="btn btn-default">Register</a>
            </form>
            <a href="forgotpwd.php">Forgot password?</a>
        </div>
    </div>
<?php
include ('layouts/footer.php');
?>