<?php
//for adding user
function addUser($firstName,$lastName,$email,$password,$gender){
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("users.xml", LIBXML_NOBLANKS);

    $users=simplexml_load_file("users.xml") or die("Error: Cannot create object");
    $root = $xml->documentElement;
    $user = $xml->createElement("user");
    if(!(bool)$users->user){
        $id = $xml->createElement('id',1);
    } elseif ((bool)$users->user && (bool)end($users)->id){
        $id = $xml->createElement('id',2);
    } else {
        $id = $xml->createElement('id',(string)end(end($users))->id + 1);  // autoincrement id
    }
    $firstName = $xml->createElement("firstname",$firstName);
    $lastName = $xml->createElement("lastname",$lastName);
    $email = $xml->createElement("email",$email);
    $password = $xml->createElement("password",$password);
    $gender = $xml->createElement("gender",$gender);
    $avatar = $xml->createElement('avatar',null);
    $lat = $xml->createElement('lat',null);
    $lng = $xml->createElement('lng',null);


    $user->appendChild($id);
    $user->appendChild($firstName);
    $user->appendChild($lastName);
    $user->appendChild($email);
    $user->appendChild($password);
    $user->appendChild($gender);
    $user->appendChild($avatar);
    $user->appendChild($lat);
    $user->appendChild($lng);

    $root->appendChild($user);

    $xml->save("users.xml");
}

//for email checking
function emailExist($email){
    $xml=simplexml_load_file("users.xml") or die("Error: Cannot create object");
    $a = true;
    foreach($xml->user as $elem){
        if((string)$elem->email == $email){
            $a = false;
        }
    }
    return $a;
}


//check password in db
function checkPasswordByEmail($email,$password){
    $bool = false;

    $xml=simplexml_load_file("users.xml") or die("Error: Cannot create object");

    foreach($xml->user as $elem){
        if($elem->email == $email){
            $id = (string)$elem->id;
            $accountPassword = (string)$elem->password;
            $bool = password_verify($password,$accountPassword);
        }
    }
    return ['bool'=>$bool,'id'=>$id];
}

//select user by id
function selectUserById($id){
    $xml=simplexml_load_file("users.xml") or die("Error: Cannot create object");
    foreach($xml->user as $elem){
        if($elem->id == $id){
            $array =  (array)$elem;
        }
    }
    return $array;
}

//change user's avatar

function changeAvatar($avatar,$user_id){
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("users.xml", LIBXML_NOBLANKS);
    $root = $xml->documentElement;

    $i = 0;
    foreach($root->getElementsByTagName('user') as $user){
        if($root->getElementsByTagName('user')->item($i)->firstChild->nodeValue == $user_id){
            //item(6) is avatar in user
            $root->getElementsByTagName('user')->item($i)->childNodes->item(6)->nodeValue = $avatar;
            $xml->save('users.xml');
            break;
        }
        $i++;
    }
}

//select images by user id
function selectImagesByUserId($userId){
    $dom = new DOMDocument();
    $dom->load("gallery.xml", LIBXML_NOBLANKS);
    $root = $dom->documentElement;
//    var_dump($root->nodeValue);
    if($root->nodeValue == ''){
        return [];
    }
    $xml=simplexml_load_file("gallery.xml") or die("Error: Cannot create object");
    $array = [];
    foreach($xml->image as $elem){
        if($elem->userId == $userId){
            $array[] = (array)$elem;
        }
    }
    return $array;
}

//delete image by id

function deleteImageById($imageId){
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("gallery.xml", LIBXML_NOBLANKS);
    $root = $xml->documentElement;

    $i = 0;
    foreach($root->getElementsByTagName('image') as $image){
        if($root->getElementsByTagName('image')->item($i)->firstChild->nodeValue == $imageId){
            $root->getElementsByTagName('image')->item($i)->parentNode->removeChild($root->getElementsByTagName('image')->item($i));
            $xml->save('gallery.xml');
            break;
        }
        $i++;
    }
}

//add image to gallery

function addImage($userId,$imageName){
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("gallery.xml", LIBXML_NOBLANKS);

    $images=simplexml_load_file("gallery.xml") or die("Error: Cannot create object");
    $root = $xml->documentElement;
    $image = $xml->createElement("image");
    if(!(bool)$images->image){
        $id = $xml->createElement('id',1);
    } elseif ((bool)$images->image && (bool)end($images)->id){
        $id = $xml->createElement('id',2);
    } else {
        $id = $xml->createElement('id',(string)end(end($images))->id + 1);  // autoincrement id
    }

    $userId = $xml->createElement("userId",$userId);
    $imageName = $xml->createElement("name",$imageName);

    $image->appendChild($id);
    $image->appendChild($userId);
    $image->appendChild($imageName);

    $root->appendChild($image);

    $xml->save("gallery.xml");
}

//delete avatar by user id

function deleteAvatarByUserId($user_id){
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("users.xml", LIBXML_NOBLANKS);
    $root = $xml->documentElement;

    $i = 0;
    foreach($root->getElementsByTagName('user') as $user){
        if($root->getElementsByTagName('user')->item($i)->firstChild->nodeValue == $user_id){
            //item(6) is avatar in user
            $root->getElementsByTagName('user')->item($i)->childNodes->item(6)->nodeValue = '';
            $xml->save('users.xml');
            break;
        }
        $i++;
    }
}

//check if image is from gallery

function imageFromGallery($imageName) {
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("gallery.xml", LIBXML_NOBLANKS);
    $root = $xml->documentElement;

    $a = false;
    foreach ($root->getElementsByTagName('image') as $image) {
        if ($image->childNodes->item(2)->nodeValue == $imageName) {
            $a = true;
            break;
        }
    }
    return $a;
}

//get images for concrete page
//4,
function getImages($count,$fromWhere,$array){
    $newArray = [];
    for($i = 0; $i < $count; $i++){
        if($array[$fromWhere + $i] == null) break;
        $newArray[] = $array[$fromWhere + $i];
    }
    return $newArray;
}

//change password by user email

function changePasswordByEmail($changepwd,$email) {
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $xml->load("users.xml", LIBXML_NOBLANKS);
    $root = $xml->documentElement;

    $i = 0;
    foreach ($root->getElementsByTagName('user') as $user) {
        if ($root->getElementsByTagName('user')->item($i)->childNodes->item(3)->nodeValue == $email) {
            //item(6) is avatar in user
            $root->getElementsByTagName('user')->item($i)->childNodes->item(4)->nodeValue = $changepwd;
            $bool = $xml->save('users.xml');
            return (bool)$bool;
        }
        $i++;
    }
}

//get coordinates by user id

function getLatLng($userId){
    $latLng = [];
    $xml=simplexml_load_file("users.xml") or die("Error: Cannot create object");
    foreach($xml->user as $elem){
        if($elem->id == $userId){
            $array =  (array)$elem;
            $lat = (string)$elem->lat;
            $lng = (string)$elem->lng;
            $latLng['lat'] = $lat;
            $latLng['lng'] = $lng;
            break;
        }
    }
    return $latLng;
}