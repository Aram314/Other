<?php
session_start();
include("functions.php");
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}
$user_id = $_SESSION['user_id'];
$image_id = $_GET['id'];
$image_name = $_GET['name'];
$currentPage = $_GET['currentPage'];

deleteImageById($image_id);
if(file_exists('galleryUploads/' . $image_name)){
    unlink('galleryUploads/' . $image_name);
}

header("location:gallery.php?page=$currentPage");