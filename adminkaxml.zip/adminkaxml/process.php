<?php
session_start();
include('functions.php');

if(isset($_POST['register'])) {
    $a = true;

//    FIRSTNAME
    if (isset($_POST['firstName']) && !empty($_POST['firstName'])) {
        $firstName = strip_tags($_POST['firstName']);
        $_SESSION['firstName'] = $firstName;
        unset($_SESSION['firstName_error']);
    } else {
        $_SESSION['firstName_error'] = 'First name is missing!';
        header('location:index.php');
        $a = false;
    }


//    LASTNAME
    if (isset($_POST['lastName']) && !empty($_POST['lastName'])) {
        $lastName = strip_tags($_POST['lastName']);
        $_SESSION['lastName'] = $lastName;
        unset($_SESSION['lastName_error']);
    } else {
        $_SESSION['lastName_error'] = 'LastName is missing!';
        header('location:index.php');
        $a = false;
    }


//    GENDER
    if (isset($_POST['gender']) && !empty($_POST['gender'])) {
        $gender = strip_tags($_POST['gender']);
        $_SESSION['gender'] = $gender;
        unset($_SESSION['gender_error']);
    } else {
        $_SESSION['gender_error'] = 'Gender is missing!';
        header('location:index.php');
        $a = false;
    }


//    EMAIL
    if (isset($_POST['email']) && !empty($_POST['email'])) {
        $email = strip_tags($_POST['email']);
        $_SESSION['email'] = $email;
        unset($_SESSION['email_error']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['email_error'] = 'Email is not valid!';
            header('location:index.php');
            $a = false;
        }
    } else {
        $_SESSION['email_error'] = 'Email is missing!';
        header('location:index.php');
        $a = false;
    }


//    PASSWORD
    if (isset($_POST['pwd']) && !empty($_POST['pwd'])) {
        $password = strip_tags($_POST['pwd']);
        $_SESSION['pwd'] = $password;
        unset($_SESSION['pwd_error']);
    } else {
        $_SESSION['pwd_error'] = 'Password is missing!';
        header('location:index.php');
        $a = false;
    }

    if(!$a) die;

//    CONFIRM PASSWORD
    $confirmPassword = $_POST['confirmpwd'];

    if(!emailExist($email)){
        $_SESSION['email_error'] = 'Email already exists!';
        header('location:index.php');
        die;
    }

    if ($password == $confirmPassword) {
        $password = crypt($password);
        addUser($firstName,$lastName,$email,$password,$gender);
    } else {
        $_SESSION['pwd_error'] = 'Passwords don\'t match!';
        header('location:index.php');
        die;
    }

    header('location:login.php');
}