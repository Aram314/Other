<?php
session_start();
include ('layouts/header.php');
?>

    <div class='row'>
        <div class="col-md-8 col-md-offset-2">
            <h2 class="text-center">Registration Form</h2>
            <form action="process.php" method="post">


                <!--            FIRSTNAME-->
                <div class="form-group">
                    <label for="firstName">First name:</label>
                    <input type="text" class="form-control" id="firstname" value="<?php
                    echo isset($_SESSION['firstName']) ? $_SESSION['firstName'] : '';
                    ?>" placeholder="Enter your name" name="firstName">
                    <?php
                    if(isset($_SESSION['firstName_error'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['firstName_error'];
                            unset($_SESSION['firstName_error']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>


                <!--            LASTNAME-->
                <div class="form-group">
                    <label for="lastName">Last name:</label>
                    <input type="text" class="form-control" id="lastname" value="<?php
                    echo isset($_SESSION['lastName']) ? $_SESSION['lastName'] : '';
                    ?>" placeholder="Enter your last name" name="lastName">
                    <?php
                    if(isset($_SESSION['lastName_error'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['lastName_error'];
                            unset($_SESSION['lastName_error']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>


                <!--            GENDER-->
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <div class="radio">
                        <label><input type="radio" name="gender" value="male" <?php
                            if(isset($_SESSION['gender']) && $_SESSION['gender'] == 'male'){
                                echo checked;
                            }
                            ?>>Male</label>
                    </div>
                    <div class="radio">
                        <label><input type="radio" name="gender" value="female" <?php
                            if(isset($_SESSION['gender']) && $_SESSION['gender'] == 'female'){
                                echo checked;
                            }
                            ?>>Female</label>
                    </div>
                    <?php
                    if(isset($_SESSION['gender_error'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['gender_error'];
                            unset($_SESSION['gender_error']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>


                <!--            EMAIL-->
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" class="form-control" id="email" value="<?php
                    echo isset($_SESSION['email']) ? $_SESSION['email'] : '';
                    ?>" placeholder="Enter email" name="email">
                    <span id = 'emailexist'>
                    <?php
                    if(isset($_SESSION['email_error'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo  $_SESSION['email_error'];
                            unset($_SESSION['email_error']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    </span>
                </div>


                <!--            PASSWORD-->
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
                    <?php
                    if(isset($_SESSION['pwd_error'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['pwd_error'];
                            unset($_SESSION['pwd_error']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>


                <!--            CONFIRM PASSWORD-->
                <div class="form-group">
                    <label for="confirmpwd">Confirm password:</label>
                    <input type="password" class="form-control" id="confirmpwd" placeholder="Confirm password" name="confirmpwd">
                </div>


                <button type="submit" name="register" class="btn btn-default">Register</button>
                <a href="login.php" class="btn btn-default">Login</a>
            </form>
        </div>
    </div>
    <script src="js/email.js"></script>
<?php
include ('layouts/footer.php');
?>