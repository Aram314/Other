$(function(){
    var emailexist = $('#emailexist');
    $('#email').on('blur',function(){
        var email = $(this).val();
        var data = {
            'email': email
        };

        $.ajax({
            url:"emailprocess.php",
            method:'post',
            data:data,
            dataType:'json',
            success:function(response){
                if(response.msg){
                    emailexist.html('<div class="alert alert-danger">'+response.msg+'</div>');
                } else {
                    emailexist.html("");
                }
            }
        })
    })
});