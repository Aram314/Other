<?php
session_start();
if(isset($_SESSION['newpwdemail']) && !empty($_SESSION['newpwdemail'])){
    include('layouts/header.php');?>

    <div class='row'>
        <div class="col-md-8 col-md-offset-2">
            <h2 class="text-center">Change your password</h2>
            <form action="dbchange.php" method="post">
                <div class="form-group">
                    <label for="changepwd">Chanage password for <?php echo $_SESSION['newpwdemail'] ?>:</label>
                    <input type="password" class="form-control" id="changepwd" placeholder="Enter new password" name="changepwd">
                    <?php
                    if(isset($_SESSION['changepwd_err'])){
                        ?>
                        <div class="alert alert-danger">
                            <?php
                            echo $_SESSION['changepwd_err'];
                            unset($_SESSION['changepwd_err']);
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <button type="submit" class="btn btn-default">Set password</button>
            </form>
        </div>
    </div>


    <?php
//    unset($_SESSION['newpwdemail']);
} else {
    header("location:login.php");
    unset($_SESSION['newpwdemail']);
    die;
}