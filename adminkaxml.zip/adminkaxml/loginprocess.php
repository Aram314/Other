<?php
session_start();
include('functions.php');

if (isset($_POST['email']) && !empty($_POST['email'])) {
    $email = strip_tags($_POST['email']);
    $_SESSION['email'] = $email;
    unset($_SESSION['email_empty']);
} else {
    $_SESSION['email'] = "";
    $_SESSION['email_empty'] = 'Email is missing!';
    header("location:login.php");
    die;
}

$password = $_POST['pwd'];

if(!emailExist($email)){

    //PASSWORDY STUGEL

    if(checkPasswordByEmail($email,$password)['bool']){
        $_SESSION['user_id'] = checkPasswordByEmail($email,$password)['id'];
        unset($_SESSION['wrong_password']);
        header("location:profile.php");
        die;
    } else {
        $_SESSION['wrong_password'] = 'Invalid password.';
        header("location:login.php");
        die;
    }
} else {
    $_SESSION['email'] = $email;
    $_SESSION['email_empty'] = 'Account isn\'t valid';
    header("location:login.php");
    die;
}