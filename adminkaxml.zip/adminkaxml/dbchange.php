<?php
session_start();
include('functions.php');
if(!(isset($_SESSION['newpwdemail']) && !empty($_SESSION['newpwdemail']))){
    header("location:login.php");
    unset($_SESSION['newpwdemial']);
    unset($_SESSION['changepwd_err']);
    die;
} elseif(!(isset($_POST['changepwd']) && !empty($_POST['changepwd']))){
    $_SESSION['changepwd_err'] = 'Password is missing!';
    header("location:newpwdinput.php");
    die;
} else {
    $changepwd = $_POST['changepwd'];
    $changepwd = crypt($changepwd);
    $email = $_SESSION['newpwdemail'];

    $query = changePasswordByEmail($changepwd,$email);

    unset($_SESSION['newpwdemail']);
    unset($_SESSION['changepwd_err']);

    if($query){
        header("location:login.php");
    } else {
        $_SESSION['changepwd_err'] = "Password is not changed";
        header("location:newpwdinput.php");
    }
}
