<?php
include('functions.php');
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}

$user_id = $_SESSION['user_id'];

if(isset($_POST['upload'])) {
    $target_dir = "galleryUploads/";
    $target_file_name = uniqid() . basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $target_file_name ;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

// Check if image file is a actual image or fake image
//    var_dump($_FILES["image"]["tmp_name"]);die;
    if($_FILES["image"]["tmp_name"] == ''){
        $_SESSION['uploadError'] = "Select an image.";
        header('location:profile.php');
        die;
    }
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        $_SESSION['uploadError'] = "File is not an image.";
        header('location:profile.php');
        $uploadOk = 0;
        die;
    }

// Check if file already exists
    if (file_exists($target_file)) {
        $_SESSION['uploadError'] = "Sorry, file already exists.";
        header('location:profile.php');
        $uploadOk = 0;
        die;
    }
// Check file size
    if ($_FILES["image"]["size"] > 1000000) {
        $_SESSION['uploadError'] = "Sorry, your file is too large.";
        header('location:profile.php');
        $uploadOk = 0;
        die;
    }
// Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif") {
        $_SESSION['uploadError'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        header('location:profile.php');
        $uploadOk = 0;
        die;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $_SESSION['uploadError'] = "Sorry, your file was not uploaded.";
        header('location:profile.php');
        die;
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {

            changeAvatar($target_file_name, $user_id);

            if(isset($_POST['current_img']) && !empty($_POST['current_img']) ){
                if(!imageFromGallery($_POST['current_img'])) {
                    if (file_exists($target_dir . $_POST['current_img'])) {
                        unlink($target_dir . $_POST['current_img']);
                    }
                }
            }

            header('location:profile.php');
        } else {
            $_SESSION['uploadError'] = "Sorry, there was an error uploading your file.";
            header('location:profile.php');
            die;
        }
    }
}