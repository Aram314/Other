<?php
include('functions.php');
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}

$user_id = $_SESSION['user_id'];
$account = selectUserById($user_id);
$latLng = getLatLng($user_id);
?>

<?php
include('layouts/header.php');
?>

    <link rel="stylesheet" href="css/upload_button.css">
    <script src="js/upload_button.js"></script>
    <!--NAVBAR-->

    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="profile.php"><?php echo $account['firstname'] . " " . $account['lastname'] ?></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="profile.php">Home</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br>
    <br><br>

<div class="col-sm-4">
    <img src="<?php
    if($account['avatar'] && file_exists('galleryUploads/' . $account['avatar'])){
        echo 'galleryUploads/' . $account['avatar'];
    } else {
        echo 'images/' . $account['gender'] . '.jpg';
    }
    ?>" alt="Avatar picture" width="220px" height="190px" class="img-rounded">
    <br><br>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label class="file_upload">
            <span class="button">Select</span>
            <input type="file" name="image">
        </label>
        <input type="hidden" name="current_img" value="<?php echo $account['avatar']; ?>">
        <button type="submit" name="upload" class="upload">Upload</button>
    </form>
    <br>
    <button type="button" class="upload" data-toggle="modal" data-target="#myModal">Delete avatar</button>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Delete</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure?</p>
                </div>
                <div class="modal-footer">
                    <a href="deleteAvatar.php?avatar=<?php echo $account['avatar']?>" type="button" class="btn btn-default">Yes</a>
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
    <br><br><br>
<?php
if(isset($_SESSION['uploadError'])){
    ?>
    <span class="alert alert-danger">
        <?php
        echo $_SESSION['uploadError'];
        unset($_SESSION['uploadError']);
        ?>
    </span>
    <?php
}
?>
</div>

    <div id="map" class = 'col-sm-4 col-sm-offset-4 col-xs-12' style="height: 250px"></div>
    <br><br>
    <div id="floating-panel" class = 'col-sm-4 col-sm-offset-4 col-xs-12'>
        <input onclick="mark();" type=button value="Mark me on the map" class="upload"><br><br>
        <input onclick="saveMark();" type=button value="Save my place" class="upload"><br><br>
        <input onclick="deleteMarkers();" type=button value="Delete Markers" class="upload"><br><br>
    </div>
    <span id="demo" class = 'col-sm-4 col-sm-offset-8 col-xs-12' style="color:red"></span>


    <script>
        var map;
        var markers = [];
        var mark;
        var saveMark;
        var latLng = [];


        function initMap() {
            var myLatLng = {lat:<?php echo $latLng['lat'] ? $latLng['lat'] : 40.1 ?>, lng:<?php echo $latLng['lng'] ? $latLng['lng'] : 44.1 ?> };

            map = new google.maps.Map(document.getElementById('map'), {
                zoom: 8,
                center: myLatLng,
                mapTypeId: 'roadmap'
            });

            // This event listener will call addMarker() when the map is clicked.
            mark = function() {
                map.addListener('click', function (event) {
                    addMarker(event.latLng,true);
                    latLng = event.latLng.toString().slice(1,-1).split(', ');
                });
            };
            saveMark = function(){
                google.maps.event.clearListeners(map, 'click');
                //aystex petq a xml-um save ani latLngy
                var xhttp = new XMLHttpRequest();
                if(latLng.length == 0){
                    document.getElementById("demo").innerHTML = 'At first you need to mark yourself!!';
                    return;
                }
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("demo").innerHTML = xhttp.responseText;
                    }
                };


                xhttp.open("GET", "addMark.php?lat="+latLng[0]+"&lng="+latLng[1], true);
                xhttp.send();

                console.log(latLng);
            };
            // Adds a marker at the center of the map.
            if(<?php echo (bool)$latLng['lat'] . '0' ?>){
                addMarker(myLatLng,false);
            }
        }

        // Adds a marker to the map and push to the array.
        function addMarker(location,bool) {
            var marker = new google.maps.Marker({
                position: location,
                map: map
            });
            if(bool){
                deleteMarkers();
            }
            markers.push(marker);
        }

        // Sets the map on all markers in the array.
        function setMapOnAll(map) {
            for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(map);
            }
        }

        // Removes the markers from the map, but keeps them in the array.
        function clearMarkers() {
            setMapOnAll(null);
        }

        // Shows any markers currently in the array.
        function showMarkers() {
            setMapOnAll(map);
        }

        // Deletes all markers in the array by removing references to them.
        function deleteMarkers() {
            clearMarkers();
            markers = [];
            latLng = [];
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("demo").innerHTML = xhttp.responseText;
                }
            };

            xhttp.open("GET", "deleteMark.php", true);
            xhttp.send();
        }
    </script>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcvt2b6oQhDe-YdFxrNOrV8mzr9ueHcvo&callback=initMap">
    </script>




<?php
include ('layouts/footer.php');
?>