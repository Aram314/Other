<?php
session_start();

require "vendor/autoload.php";

include('functions.php');
if (isset($_POST['forgot']) && !empty($_POST['forgot']) || isset($_SESSION['emailfromchangepwd'])) {
    if(!empty($_POST['forgot'])){
        $email = strip_tags($_POST['forgot']);
    } elseif(isset($_SESSION['emailfromchangepwd'])){
        $email = strip_tags($_SESSION['emailfromchangepwd']);
    }
    $_SESSION['forgot'] = $email;
    unset($_SESSION['forgot_err']);
    unset($_SESSION['emailfromchangepwd']);

} else {
    unset($_SESSION['emailfromchangepwd']);
    $_SESSION['forgot'] = "";
    $_SESSION['forgot_err'] = 'Email is missing!';
    header("location:forgotpwd.php");
    die;
}


if(!emailExist($email)){
    include('sendmailprocess.php');
    include('layouts/header.php');
    ?>

    <h1 class="text-center">We will send you a message with verification code!</h1>
    <h2 class="text-center">Enter code here!</h2>

    <div class="col-md-4 col-md-offset-4">
        <form action="changepwd.php" method="post">
            <div class="form-group">
                <label for="code">Verification code:</label>
                <input type="text" class="form-control" id="code" placeholder="Enter verification code" name="code">
                <?php
                if(isset($_SESSION['code_err'])){
                    ?>
                    <div class="alert alert-danger">
                        <?php
                        echo $_SESSION['code_err'];
                        unset($_SESSION['code_err']);
                        ?>
                    </div>
                    <?php
                }
                ?>
            </div>
            <button type="submit" class="btn btn-default">Submit!</button>
        </form>
    </div>

    <?php
    include('layouts/footer.php');
} else {
    $_SESSION['forgot_err'] = 'Account with email ' . $email . ' is not signed!';
    header('location:forgotpwd.php');
}

