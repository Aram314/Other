<?php
include('functions.php');
if(isset($_POST['email'])) {
    $email = $_POST['email'];
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if (!emailExist($email)) {
            $error = [
                'msg' => 'Email already exists!'
            ];
        } else {
            $error = [
                'msg' => null
            ];
        }
    } else {
        if(empty($email)){
            $error = [
                'msg' => 'Email is missing!',
            ];
        } else {
            $error = [
                'msg' => 'Email is not valid!',
            ];
        }
    }
}
echo json_encode($error);