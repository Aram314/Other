<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}
$user_id = $_SESSION['user_id'];

function deleteLatLng($userId){
    $dom = new DOMDocument();
    $dom->formatOutput = true;
    $dom->load("users.xml", LIBXML_NOBLANKS);
    $root = $dom->documentElement;
    $i = 0;
    foreach($root->getElementsByTagName('user') as $user){
        if($root->getElementsByTagName('user')->item($i)->firstChild->nodeValue == $userId){
            $root->getElementsByTagName('user')->item($i)->childNodes->item(7)->nodeValue = "";
            $root->getElementsByTagName('user')->item($i)->childNodes->item(8)->nodeValue = "";
            $dom->save('users.xml');
            break;
        }
        $i++;
    }
}

deleteLatLng($user_id);