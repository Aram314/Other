<?php
include('functions.php');
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}

$user_id = $_SESSION['user_id'];
$account = selectUserById($user_id);

?>

<?php
include('layouts/header.php');
?>
<link rel="stylesheet" href="css/upload_button.css">
<script src="js/upload_button.js"></script>

<!--NAVBAR-->

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="profile.php"><?php echo $account['firstname'] . " " . $account['lastname'] ?></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li><a href="profile.php">Home</a></li>
                <li class="active"><a href="gallery.php">Gallery</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
            </ul>
        </div>
    </div>
</nav>
<br>
<br>
<div class="row">

    <div class="col-lg-12">
        <h1 class="page-header text-center">Gallery</h1>
        <?php
        $images = selectImagesByUserId($user_id);
        $countPerPage = 4;
        $pageCount = ceil(count($images) / $countPerPage);
        if(!isset($_GET['page']) && empty($_GET['page']) || $_GET['page'] == 0){
            $pageNumber = 1;
        } else {
            $pageNumber = $_GET['page'];

        }

        $fromWhere = $countPerPage * ($pageNumber - 1);
        $images = getImages($countPerPage,$fromWhere,$images);
        $i = 0;

        if(count($images) == 0){
            echo 'No images!';
        } else {

            foreach($images as $image){
                $i++;
                ?>
                <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                    <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-image="<?php echo 'galleryUploads/' . $image['name'] ?>" data-target="#image-gallery">
                        <img class="img-responsive" src="<?php echo 'galleryUploads/' . $image['name'] ?>" alt="Picture">
                    </a>
                    <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal<?php echo $i ?>">Delete</button>
                    <a class="btn btn-default" href="setAsAvatar.php?avatar=<?php echo $account['avatar']?>&imageName=<?php echo $image['name']?>&currentPage=<?php echo $pageNumber?>">Set as avatar</a>
                    <br><br>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="myModal<?php echo $i ?>" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Delete</h4>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure?</p>
                            </div>
                            <div class="modal-footer">
                                <a href="delete.php?id=<?php echo $image['id']?>&name=<?php echo $image['name']?>&currentPage=<?php
                                if(count($images) == 1){
                                    echo $pageNumber - 1;
                                } else {
                                    echo $pageNumber;
                                }
                                ?>" type="button" class="btn btn-default">Yes</a>
                                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        }

        ?>

    </div>
    <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="image-gallery-title"></h4>
                </div>
                <div class="modal-body">
                    <img id="image-gallery-image" class="img-responsive" src="">
                </div>
                <div class="modal-footer">

                    <div class="col-md-2">
                        <button type="button" class="btn btn-primary" id="show-previous-image">Previous</button>
                    </div>

                    <div class="col-md-8 text-justify" id="image-gallery-caption">
                    </div>

                    <div class="col-md-2">
                        <button type="button" id="show-next-image" class="btn btn-default">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<br><br>
<form action="galleryUpload.php" method="post" enctype="multipart/form-data">
    <label class="file_upload">
        <span class="button">Add picture</span>
        <input type="file" name="fileToUpload">
    </label>
    <button type="submit" name="galleryUpload" class="upload">Upload</button>
    <input type="hidden" name="currentPage" value = "<?php echo $pageNumber ?>">
    <input type="hidden" value="<?php
    if(count($images) == 4 && $pageCount == $pageNumber){
        echo $pageCount + 1;
    } else {
        echo $pageCount;
    }
    ?>" name="pageCount">
</form>
<br><br>
<?php
if(isset($_SESSION['uploadError'])){
    ?>
    <span class="alert alert-danger">
        <?php
        echo $_SESSION['uploadError'];
        unset($_SESSION['uploadError']);
        ?>
    </span>
    <?php
}
?>

<div id="pagination">
        <?php
        if($pageCount > 1){
            ?>
    <ul class="pagination pagination-sm">
            <?php
            for($j = 1; $j <= $pageCount; $j++){
                if($j == $pageNumber){
                    ?>
                    <li class="active"><a href="gallery.php?page=<?php echo $j ?>"><?php echo $j ?></a></li>
                    <?php
                } else {
                    ?>
                    <li><a href="gallery.php?page=<?php echo $j ?>"><?php echo $j ?></a></li>
                    <?php
                }
            }
            ?>
    </ul>
        <?php
        }
        ?>
</div>

<script src="js/modal.js"></script>
<?php
include ('layouts/footer.php');
?>
