<?php
session_start();
if(isset($_POST['code']) && !empty($_POST['code'])){
    $code = $_POST['code'];
    // echo $_SESSION['forgot'];die;
    if($code == $_SESSION['random']){
        $_SESSION['newpwdemail'] = $_SESSION['forgot'];
        unset($_SESSION['random']);
        unset($_SESSION['forgot']);
        header("location:newpwdinput.php");
    } else {
        $_SESSION['emailfromchangepwd'] = $_SESSION['forgot'];
        unset($_SESSION['forgot']);
        unset($_SESSION['random']);
        $_SESSION['code_err'] = 'Code is wrong! We have sent you message again, check your email!';
        header("location:sendmail.php");
    }
} else {
    $_SESSION['emailfromchangepwd'] = $_SESSION['forgot'];
    unset($_SESSION['forgot']);
    unset($_SESSION['random']);
    $_SESSION['code_err'] = 'Code is wrong! We have sent you message again, check your email!';
    header("location:sendmail.php");
    die;
}
