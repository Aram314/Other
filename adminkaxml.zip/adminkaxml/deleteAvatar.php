<?php
session_start();
include("functions.php");
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}
$user_id = $_SESSION['user_id'];
$avatar = $_GET['avatar'];
if($avatar == ''){
    $_SESSION['uploadError'] = 'Avatar is not set!';
    header("location:profile.php");
    die;
}

deleteAvatarByUserId($user_id);

if(!imageFromGallery($avatar)){
    if(file_exists('galleryUploads/' . $avatar)){
        unlink('galleryUploads/' . $avatar);
    }
}



header("location:profile.php");