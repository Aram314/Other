<?php
include('functions.php');
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:login.php');
    die;
}

$user_id = $_SESSION['user_id'];
if(!empty($_GET['avatar'])){
    $avatar = $_GET['avatar'];
}
$imageName = $_GET['imageName'];
$currentPage = $_GET['currentPage'];


changeAvatar($imageName, $user_id);
if(!empty($_GET['avatar'])){
    if(!imageFromGallery($avatar)){
        if(file_exists('galleryUploads/' . $avatar)){
            unlink('galleryUploads/' . $avatar);
        }
    }
}


header("location:gallery.php?page=$currentPage");